# BMDG Works Cloud Server — Phase 1 (Test Scaffold)

ఈ ప్యాకేజీ మీ Windows Offline CRM కోసం cloud APIకి ప్రారంభ scaffold మాత్రమే. ఇది ఇంకా మీ Tkinter CRMతో connect కాలేదు; అసలు CRM records sync చేయడానికి client-side integration, schema mapping, login/role permissions, conflict UI మరియు end-to-end tests తదుపరి దశలో అవసరం.

## ఇందులో ఉన్నవి
- `api/main.py`: FastAPI service
- `render.yaml`: Render deployment blueprint
- `requirements.txt`: Python dependencies

## Deploy — Supabase + Render (test environment)
1. Supabaseలో కొత్త project సృష్టించండి. Database passwordను సురక్షితంగా భద్రపరచండి.
2. Supabase Project Settings → Databaseలోని connection string/URIని తీసుకోండి. Render నుంచి కనెక్ట్ చేయడానికి సరైన connection URI ఉపయోగించండి; passwordను chatలో పంపవద్దు.
3. ఈ folderను మీ private GitHub repositoryకి upload చేయండి.
4. Renderలో New → Blueprint ఎంచుకుని repository connect చేయండి. `render.yaml` service సృష్టిస్తుంది.
5. Render Environmentలో `DATABASE_URL`కు Supabase connection URI ఇవ్వండి. `BMDG_API_KEY`ను పొడవైన random secretగా ఉంచండి; code లేదా GitHubలో పెట్టవద్దు.
6. Deploy అయ్యాక `https://YOUR-SERVICE.onrender.com/health` తెరిచి `{"status":"ok"...}` వస్తుందో చూడండి.
7. API keyని header `X-BMDG-API-Key`గా పంపి `POST /admin/initialize` ఒక్కసారి పిలవండి. ఇది cloud sync tables సృష్టిస్తుంది.
8. `/docs`లో API documentation చూడవచ్చు. ఇది health/test కోసం మాత్రమే; ఇంకా production data upload చేయవద్దు.

## ముఖ్యమైన పరిమితులు
- Render Free service idle తర్వాత sleep అవ్వవచ్చు; మొదటి request ఆలస్యం కావచ్చు.
- Supabase/Render free tier పరిమితులు మారవచ్చు; deploymentకు ముందు తాజా pricing/limits చూడండి.
- ఈ scaffoldలో ఒక shared API key ఉంది; ఇది production multi-user authentication కాదు.
- `/sync` generic JSON records నిల్వ చేస్తుంది. CRMలోని `properties`, `owners`, `clients` మొదలైన SQLite tablesకి పూర్తి field mapping ఇంకా జోడించలేదు.
- Conflict detection ప్రాథమిక స్థాయిలో ఉంది; simultaneous editsపై user-facing resolution ఇంకా లేదు.
- Real customer data, passwords, ID documents లేదా owner documentsతో productionలో ఉపయోగించవద్దు; ముందు access control, audit, backup/restore, data migration పరీక్షించాలి.
- API key, database passwordలను ఎవరికీ chatలో పంపకండి.
