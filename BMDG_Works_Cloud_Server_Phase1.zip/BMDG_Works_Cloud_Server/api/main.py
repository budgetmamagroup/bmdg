import os, json, secrets
from datetime import datetime, timezone
from typing import Any
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
import psycopg
from psycopg.rows import dict_row

APP_NAME = "BMDG Works Cloud Sync API"
DATABASE_URL = os.getenv("DATABASE_URL", "")
BMDG_API_KEY = os.getenv("BMDG_API_KEY", "")

app = FastAPI(title=APP_NAME, version="0.1.0")

class SyncOperation(BaseModel):
    operation_id: str = Field(min_length=8, max_length=128)
    device_id: str = Field(min_length=1, max_length=128)
    table_name: str = Field(min_length=1, max_length=64, pattern=r"^[a-z][a-z0-9_]*$")
    record_id: str = Field(min_length=1, max_length=256)
    data: dict[str, Any]
    updated_at: str | None = None
    deleted: bool = False

class SyncRequest(BaseModel):
    operations: list[SyncOperation] = Field(max_length=500)
    since: str | None = None
    device_id: str = Field(min_length=1, max_length=128)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def db():
    if not DATABASE_URL:
        raise HTTPException(503, "DATABASE_URL is not configured. Set it in the hosting environment.")
    try:
        return psycopg.connect(DATABASE_URL, row_factory=dict_row, connect_timeout=10, sslmode="require")
    except Exception as exc:
        raise HTTPException(503, f"Database connection failed: {type(exc).__name__}")


def authorize(x_bmdg_api_key: str | None):
    if not BMDG_API_KEY:
        raise HTTPException(503, "BMDG_API_KEY is not configured. Set a strong secret in hosting settings.")
    if not x_bmdg_api_key or not secrets.compare_digest(x_bmdg_api_key, BMDG_API_KEY):
        raise HTTPException(401, "Invalid API key")

@app.get("/")
def root():
    return {"service": APP_NAME, "status": "running", "note": "Health check only; CRM sync requires client integration."}

@app.get("/health")
def health():
    return {"status": "ok", "time": now_iso()}

@app.post("/admin/initialize")
def initialize(x_bmdg_api_key: str | None = Header(default=None)):
    authorize(x_bmdg_api_key)
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS bmdg_sync_records (
            table_name text NOT NULL,
            record_id text NOT NULL,
            data jsonb NOT NULL,
            updated_at timestamptz NOT NULL DEFAULT now(),
            deleted boolean NOT NULL DEFAULT false,
            last_device_id text NOT NULL,
            PRIMARY KEY (table_name, record_id)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS bmdg_sync_operations (
            operation_id text PRIMARY KEY,
            device_id text NOT NULL,
            table_name text NOT NULL,
            record_id text NOT NULL,
            received_at timestamptz NOT NULL DEFAULT now()
        )""")
        conn.commit()
    return {"status": "initialized", "tables": ["bmdg_sync_records", "bmdg_sync_operations"]}

@app.post("/sync")
def sync(payload: SyncRequest, x_bmdg_api_key: str | None = Header(default=None)):
    authorize(x_bmdg_api_key)
    accepted, duplicates, conflicts = [], [], []
    with db() as conn:
        for op in payload.operations:
            prior = conn.execute("SELECT operation_id FROM bmdg_sync_operations WHERE operation_id=%s", (op.operation_id,)).fetchone()
            if prior:
                duplicates.append(op.operation_id)
                continue
            existing = conn.execute("SELECT updated_at, data, last_device_id FROM bmdg_sync_records WHERE table_name=%s AND record_id=%s", (op.table_name, op.record_id)).fetchone()
            client_time = op.updated_at
            if existing and client_time and str(existing["updated_at"]) > client_time:
                conflicts.append({"operation_id": op.operation_id, "table_name": op.table_name, "record_id": op.record_id, "server_updated_at": str(existing["updated_at"]), "server_data": existing["data"], "server_device_id": existing["last_device_id"]})
                continue
            conn.execute("""INSERT INTO bmdg_sync_records(table_name,record_id,data,updated_at,deleted,last_device_id)
                VALUES(%s,%s,%s::jsonb,COALESCE(%s::timestamptz,now()),%s,%s)
                ON CONFLICT(table_name,record_id) DO UPDATE SET data=EXCLUDED.data, updated_at=now(), deleted=EXCLUDED.deleted, last_device_id=EXCLUDED.last_device_id""",
                (op.table_name, op.record_id, json.dumps(op.data), op.updated_at, op.deleted, op.device_id))
            conn.execute("INSERT INTO bmdg_sync_operations(operation_id,device_id,table_name,record_id) VALUES(%s,%s,%s,%s)", (op.operation_id, op.device_id, op.table_name, op.record_id))
            accepted.append(op.operation_id)
        conn.commit()
        changes = []
        if payload.since:
            rows = conn.execute("SELECT table_name,record_id,data,updated_at,deleted,last_device_id FROM bmdg_sync_records WHERE updated_at > %s::timestamptz ORDER BY updated_at LIMIT 2000", (payload.since,)).fetchall()
            changes = [dict(r) for r in rows]
    return {"accepted": accepted, "duplicates": duplicates, "conflicts": conflicts, "changes": changes, "server_time": now_iso(), "warning": "Generic sync storage only; map and test CRM tables before using production records."}
